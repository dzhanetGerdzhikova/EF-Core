﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=BookShopNew;Trusted_Connection=True";
    }
}
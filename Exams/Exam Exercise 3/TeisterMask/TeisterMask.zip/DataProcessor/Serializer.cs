﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Data;
    using Newtonsoft.Json;
    using TeisterMask.DataProcessor.ExportDto;
    using Formatting = Newtonsoft.Json.Formatting;

    public class Serializer
    {
        public static string ExportProjectWithTheirTasks(TeisterMaskContext context)
        {
            var projectsWithTask = context.Projects.ToList()
                  .Where(p => p.Tasks.Any())
                  .Select(p => new ExportProjectDto
                  {
                      TasksCount = p.Tasks.Count(),
                      ProjectName = p.Name,
                      HasEndDate = p.DueDate.HasValue ? "Yes" : "No",
                      Tasks = p.Tasks.Select(t => new ExportTaskDto
                      {
                          Name = t.Name,
                          Label = t.LabelType.ToString()
                      }).OrderBy(t => t.Name).ToArray()
                  }).OrderByDescending(p => p.TasksCount)
                  .ThenBy(p => p.ProjectName).ToArray();

            XmlSerializer serializer = new XmlSerializer(typeof(ExportProjectDto[]), new XmlRootAttribute("Projects"));
            StringBuilder sb = new StringBuilder();

            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add(string.Empty, string.Empty);

            using (StringWriter sw = new StringWriter(sb))
            {
                serializer.Serialize(sw, projectsWithTask, ns);
            }

            return sb.ToString().TrimEnd();
        }

        public static string ExportMostBusiestEmployees(TeisterMaskContext context, DateTime date)
        {
            var mostBusiestEmployess = context.Employees.ToList()
                .Where(e => e.EmployeesTasks.Any(t => t.Task.OpenDate >= date))
                .Select(em => new
                {
                    Username = em.Username,
                    Tasks = em.EmployeesTasks
                    .Where(e => e.Task.OpenDate >= date)
                    .OrderByDescending(t => t.Task.DueDate)
                    .ThenBy(t => t.Task.Name)
                    .Select(emt => new
                    {
                        TaskName = emt.Task.Name,
                        OpenDate = emt.Task.OpenDate.ToString("d", CultureInfo.InvariantCulture),
                        DueDate = emt.Task.DueDate.ToString("d", CultureInfo.InvariantCulture),
                        LabelType = emt.Task.LabelType.ToString(),
                        ExecutionType = emt.Task.ExecutionType.ToString()
                    })
                }).OrderByDescending(em => em.Tasks.Count())
                .ThenBy(em => em.Username).Take(10);

            return JsonConvert.SerializeObject(mostBusiestEmployess, Formatting.Indented);
        }
    }
}